import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { styles } from './styles';
import firebase from '../../Database/config';


const LoginScreen = ({ navigation }) => {



    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    // State variables for error messages
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const handleLogin = async () => {
        // Reset previous error messages
        setEmailError('');
        setPasswordError('');


        // Validation
        let isValid = true;
        if (!email.trim()) {
            setEmailError('Email is required');
            isValid = false;
        } else if (!isValidEmail(email)) {
            setEmailError('Please enter a valid email address');
            isValid = false;
        }
        if (!password.trim()) {
            setPasswordError('Password is required');
            isValid = false;
        }

        if (isValid) {

            setEmailError('');
            setPasswordError('');

            navigation.navigate('Home');

            // try {
            //     console.log(firebase);
            //     console.log('Email => ', email)

            //     console.log('Password => ', password)
            //     await firebase.auth().signInWithEmailAndPassword(email, password).then((result)=>{
            //         console.log(result.user)
            //     });
            //     console.log('Login success!');

            // } catch (error) {

            //     console.log('Login error:', error.message);
            // }
        }
    };

    const isValidEmail = (email) => {
        // Basic email validation, you can implement a more sophisticated validation if needed
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    };

    const onSignUp = () => {
        navigation.navigate('Signup');
        console.log('Sign Up');
    };

    const onForgot = () => {
        navigation.navigate('Forgot');
        console.log('==>Forgot<==');
    };

    return (
        <View style={styles.container}>
            <Text style={styles.header}>Login Here..</Text>
            <Text style={styles.label}>Email</Text>
            <TextInput
                style={styles.input}
                placeholder="Email"
                placeholderTextColor="#aaaaaa"
                onChangeText={(text) => setEmail(text)}
                value={email}
            />
            {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}

            <Text style={styles.label}>Password</Text>
            <TextInput
                style={styles.input}
                placeholder="Password"
                placeholderTextColor="#aaaaaa"
                secureTextEntry
                onChangeText={(text) => setPassword(text)}
                value={password}
            />
            {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}

            <View style={styles.forgotContainer}>
                <TouchableOpacity onPress={onForgot}>
                    <Text style={styles.forgotText}>Forgot password?</Text>
                </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.buttonContainer} onPress={handleLogin}>
                <Text style={styles.buttonText}>Login</Text>
            </TouchableOpacity>

            <View style={styles.signupContainer}>
                <Text style={styles.donthaveText}>Don't have an account? </Text>
                <TouchableOpacity onPress={onSignUp}>
                    <Text style={styles.signupText}>Sign up</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default LoginScreen;
