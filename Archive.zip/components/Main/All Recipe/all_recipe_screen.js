import { View, Text } from 'react-native'
import React from 'react'

export default function AllRecipeScreen() {
  return (
    <View>
      <Text>AllRecipeScreen</Text>
    </View>
  )
}