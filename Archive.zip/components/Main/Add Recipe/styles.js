import { View, Text } from 'react-native'
import React from 'react'

export default function AddRecipeScreen() {
  return (
    <View>
      <Text>Add Recipe Screen</Text>
    </View>
  )
}